Package singleton based on analysis #626409139@:
  * SingletonDiscipline

