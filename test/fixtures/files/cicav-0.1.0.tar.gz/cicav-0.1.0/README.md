Package CICAV based on analysis #6@http://localhost:3000:
  * Geometry
  * Aerodynamics
  * Propulsion

